import numpy as np
import networkx as nx
import random
import time
import torch
import dgl
from collections import defaultdict
from build_graph_kk import build_heterograph
import scipy.sparse as sp

if torch.cuda.is_available():
    device = torch.device("cuda:0")
else:
    device = torch.device("cpu")

class Augmenter:
    def __init__(self, args, features_list, is_label):
        print("loading data:")
        self.args = args
        self.features_list = features_list
        self.is_label = is_label
        self.g, self.dataset = build_heterograph(args)
        nxg = nx.Graph()
        for i, meta_path in self.dataset.links["meta"].items():
            nxg.add_edges_from(list(zip(self.dataset.links["data"][i].tocoo().row, self.dataset.links["data"][i].tocoo().col)))
        nxg.remove_edges_from(list(nx.selfloop_edges(nxg)))
        # 所有1跳节点对（删边）
        aa_edges_1 = list(nx.adamic_adar_index(nxg, nxg.edges()))
        # aa_edges_1 = [item[2] for item in aa_edges_1]
        # print("aa1:", len(aa_edges_1), max(aa_edges_1), min(aa_edges_1), sum(aa_edges_1)/len(aa_edges_1))
        # 所有2跳节点对（增边）
        valid_edge_types = set([(st, dt) for _, (st, dt) in self.dataset.links["meta"].items()])
        hop2_edges = [(s, d) for s, d in self.hop_two_edges(nxg) if (self.node_type(s), self.node_type(d)) in valid_edge_types]
        aa_edges_2 = list(nx.adamic_adar_index(nxg, hop2_edges))
        # aa_edges_2 = [item[2] for item in aa_edges_2]
        # print("aa2:", len(aa_edges_2), max(aa_edges_2), min(aa_edges_2), sum(aa_edges_2)/len(aa_edges_2))
        # 边采样：1跳节点对正排头部采样删边，2跳节点对倒排头部采样增边
        pre_sample_ratio = 1 # 采样边占比
        sample_ratio = 0.5 # 采样比例
        pre_sample_num = int(self.dataset.links["total"]*pre_sample_ratio)
        sample_num = int(pre_sample_num*sample_ratio)
        print("sample_num:", sample_num)
        aa_edges_1 = aa_edges_1+[(item[1],item[0],item[2]) for item in aa_edges_1]
        random.shuffle(aa_edges_1)
        aa_edges_hop1 = sorted(aa_edges_1, key=lambda x:x[-1])[:pre_sample_num]
        aa_edges_2 = aa_edges_2+[(item[1],item[0],item[2]) for item in aa_edges_2]
        random.shuffle(aa_edges_2)
        aa_edges_hop2 = sorted(aa_edges_2, key=lambda x:x[-1], reverse=True)[:pre_sample_num]
        self.sample_num = sample_num
        self.aa_edges_hop1 = aa_edges_hop1
        self.aa_edges_hop2 = aa_edges_hop2
    def hop_two_edges(self, g):
        exist = set(g.edges())
        edges = set()
        for m in g.nodes:
            for a in g.neighbors(m):
                for b in g.neighbors(m):
                    if (a, b) in exist or (b, a) in exist:
                        continue
                    if b > a:
                        edges.add((a, b))
        return edges
    def node_type(self, node):
        for i in range(len(self.dataset.nodes["shift"])-1):
            if node < self.dataset.nodes["shift"][i+1]:
                return i
        else: return i+1
    def triangle_aug_heterograph(self):
        t0 = time.time()
        edges_hop1_rind = np.random.choice(np.arange(len(self.aa_edges_hop1)), size=self.sample_num, replace=False)
        edges_hop1 = [item[:2] for i, item in enumerate(self.aa_edges_hop1) if i in edges_hop1_rind]
        edges_hop2_rind = np.random.choice(np.arange(len(self.aa_edges_hop2)), size=self.sample_num, replace=False)
        edges_hop2 = [item[:2] for i, item in enumerate(self.aa_edges_hop2) if i in edges_hop2_rind] 
        edge_dict_del = defaultdict(list)
        for s, d in edges_hop1:
            st, dt = self.node_type(s), self.node_type(d)
            edge_dict_del[(str(st), str(st)+"_"+str(dt), str(dt))].append((s, d))
        # for k, v in edge_dict_del.items():
        #     print("del", k, len(v))
        edge_dict_add = defaultdict(list)
        for s, d in edges_hop2:
            st, dt = self.node_type(s), self.node_type(d)
            edge_dict_add[(str(st), str(st)+"_"+str(dt), str(dt))].append((s, d))
        # for k, v in edge_dict_add.items():
        #     print("add", k, len(v))
        edge_dict = {}
        for i, meta_path in self.dataset.links["meta"].items():
            key = (str(meta_path[0]), str(meta_path[0])+"_"+str(meta_path[1]), str(meta_path[1]))
            ori = list(zip(self.dataset.links["data"][i].tocoo().row, self.dataset.links["data"][i].tocoo().col))
            # edges = set(ori)|set(edge_dict_add[key])
            # edges = set(ori)-set(edge_dict_del[key])
            edges = set(ori)-set(edge_dict_del[key])|set(edge_dict_add[key])
            # print(key, len(set(ori)), len(set(edge_dict_del[key])), len(set(edge_dict_add[key])), len(edges))
            edge_dict[i] = edges

        new_data = {}
        for r_id in edge_dict:
            i = [x[0] for x in edge_dict[r_id]]
            j = [x[1] for x in edge_dict[r_id]]
            new_data[r_id] = sp.coo_matrix(([np.nan]*len(i), (i,j)), shape=(self.dataset.nodes['total'], self.dataset.nodes['total'])).tocsr()

        edges = list(new_data.values())
        num_nodes = edges[0].shape[0]
        for i,edge in enumerate(edges):
            if i ==0:
                A = torch.from_numpy(edge.todense()).type(torch.FloatTensor).unsqueeze(-1)
            else:
                A = torch.cat([A,torch.from_numpy(edge.todense()).type(torch.FloatTensor).unsqueeze(-1)], dim=-1)
        A = torch.cat([A,torch.eye(num_nodes).type(torch.FloatTensor).unsqueeze(-1)], dim=-1).cuda()
        A[torch.isnan(A)]=0.01
        print("aug heterograph time:", time.time()-t0)
        return A

    def triangle_aug_heterograph_ogbm(self):
        t0 = time.time()
        edges_hop1_rind = np.random.choice(np.arange(len(self.aa_edges_hop1)), size=self.sample_num, replace=False)
        edges_hop1 = [item[:2] for i, item in enumerate(self.aa_edges_hop1) if i in edges_hop1_rind]
        edges_hop2_rind = np.random.choice(np.arange(len(self.aa_edges_hop2)), size=self.sample_num, replace=False)
        edges_hop2 = [item[:2] for i, item in enumerate(self.aa_edges_hop2) if i in edges_hop2_rind] 
        edge_dict_del = defaultdict(list)
        for s, d in edges_hop1:
            st, dt = self.node_type(s), self.node_type(d)
            edge_dict_del[(str(st), str(st)+"_"+str(dt), str(dt))].append((s, d))
        # for k, v in edge_dict_del.items():
        #     print("del", k, len(v))
        edge_dict_add = defaultdict(list)
        for s, d in edges_hop2:
            st, dt = self.node_type(s), self.node_type(d)
            edge_dict_add[(str(st), str(st)+"_"+str(dt), str(dt))].append((s, d))
        # for k, v in edge_dict_add.items():
        #     print("add", k, len(v))
        edge_dict = {}
        for i, meta_path in self.dataset.links["meta"].items():
            key = (str(meta_path[0]), str(meta_path[0])+"_"+str(meta_path[1]), str(meta_path[1]))
            ori = list(zip(self.dataset.links["data"][i].tocoo().row, self.dataset.links["data"][i].tocoo().col))
            # edges = set(ori)|set(edge_dict_add[key])
            # edges = set(ori)-set(edge_dict_del[key])
            edges = set(ori)-set(edge_dict_del[key])|set(edge_dict_add[key])
            # print(key, len(set(ori)), len(set(edge_dict_del[key])), len(set(edge_dict_add[key])), len(edges))
            edge_dict[i] = edges

        new_data = {}
        for r_id in edge_dict:
            i = [x[0] for x in edge_dict[r_id]]
            j = [x[1] for x in edge_dict[r_id]]
            new_data[r_id] = sp.coo_matrix(([np.nan]*len(i), (i,j)), shape=(self.dataset.nodes['total'], self.dataset.nodes['total'])).tocsr()

        edges = list(new_data.values())
        num_nodes = edges[0].shape[0]
        for i,edge in enumerate(edges):
            if i ==0:
                A = torch.from_numpy(edge.todense()).type(torch.FloatTensor).unsqueeze(-1)
            else:
                A = torch.cat([A,torch.from_numpy(edge.todense()).type(torch.FloatTensor).unsqueeze(-1)], dim=-1)
        A = torch.cat([A,torch.eye(num_nodes).type(torch.FloatTensor).unsqueeze(-1)], dim=-1).cuda()
        print("aug heterograph time:", time.time()-t0)
        return A

    def node_aug_heterograph(self, node_features, unlabel_idx, k):
        sim,sim1 = {},{}
        distance0,distance1 = {},{}

        adapt_fes = torch.cat((node_features[0],node_features[1],node_features[2]),axis=0)
            
        for i, meta_path in self.dataset.links['meta'].items():
            nid1 = self.dataset.links['data'][i].tocoo().row - self.dataset.nodes['shift'][meta_path[0]]
            nid2 = self.dataset.links['data'][i].tocoo().col - self.dataset.nodes['shift'][meta_path[1]]
            new_nid1 = self.dataset.links['data'][i].tocoo().row
            new_nid2 = self.dataset.links['data'][i].tocoo().col
            etype = str(meta_path[0]) + '_' + str(meta_path[1])
            distance0[int(meta_path[0])] = self.dataset.nodes['shift'][meta_path[0]]
            distance1[int(meta_path[1])] = self.dataset.nodes['shift'][meta_path[1]]
            
            if str(meta_path[0]) + '_' + str(meta_path[1]) == '0_0':
                [(0, 3025), (1, 5959), (2, 56)]
                sim1[int(meta_path[1])] = torch.zeros([3025,3025])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '0_1':
                sim1[int(meta_path[1])] = torch.zeros([3025,5959])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '0_2':
                sim1[int(meta_path[1])] = torch.zeros([3025,56])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '1_0':
                sim1[int(meta_path[1])] = torch.zeros([5959,3025])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '2_0':
                sim1[int(meta_path[1])] = torch.zeros([56,3025])
            
            sim[int(meta_path[0])] = sim1

            target_fe = adapt_fes[new_nid1]
            neigh_fe = adapt_fes[new_nid2]
            sim_fe = torch.sum(target_fe.mul(neigh_fe), dim=1)  # dim=len(nid1)*1,对应位置元素点乘后，每一行求和。相当于对应行的向量点积
            sim_fe = sim_fe.reshape(len(sim_fe),-1)

            for ni in range(len(nid1)):
                if nid1[ni] != nid2[ni]:
                    sim[int(meta_path[0])][int(meta_path[1])][nid1[ni]][nid2[ni]] = sim_fe[ni]

        sim2 = sim.copy()

        row = tuple(unlabel_idx.cpu().detach().numpy().tolist())
        target_fe = adapt_fes.clone().detach()  # adapt_fes: torch.Size([9040, 64])
        sim_tensor = torch.cat((sim2[0][0],sim2[0][1],sim2[0][2]),axis=1)
        for kk in range(k):
            max_id = torch.argmax(sim_tensor[unlabel_idx],1)
            if kk==0:
                neigh_fes = adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1]).clone().detach()
            else:
                neigh_fes = neigh_fes + adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1])
            
            sim_tensor[row,max_id] = 0
        neigh_fes = torch.tensor(neigh_fes/2.0, dtype=torch.float)
        adapt_fes[unlabel_idx] = neigh_fes
        
        res = []
        tmp = adapt_fes.cpu().detach().numpy().tolist()
        res.append(torch.tensor(tmp[:3025]))
        res.append(torch.tensor(tmp[3025:8984]))
        res.append(torch.tensor(tmp[8984:]))
        return res

    def node_aug_heterograph_dblp(self, node_features, unlabel_idx, k):
        sim,sim1 = {},{}
        print('self.dataset.links.items()>>>>>> ',self.dataset.links['meta'].items())
    

        adapt_fes = torch.cat((node_features[0],node_features[1],node_features[2]),axis=0)
        # adapt_fes = torch.cat((node_features[0],node_features[1]),axis=0)
        
            
        for i, meta_path in self.dataset.links['meta'].items():
            if i == 0 or i == 3:
                nid1 = self.dataset.links['data'][i].tocoo().row - self.dataset.nodes['shift'][meta_path[0]]
                nid2 = self.dataset.links['data'][i].tocoo().col - self.dataset.nodes['shift'][meta_path[1]]
                if i == 2:
                    new_nid1 = self.dataset.links['data'][i].tocoo().row
                    new_nid2 = self.dataset.links['data'][i].tocoo().col - self.dataset.nodes['shift'][meta_path[1]] + self.dataset.nodes['shift'][2]
                elif i == 5:
                    new_nid1 = self.dataset.links['data'][i].tocoo().row - self.dataset.nodes['shift'][meta_path[0]] + self.dataset.nodes['shift'][2]
                    new_nid2 = self.dataset.links['data'][i].tocoo().col    
                else:
                    new_nid1 = self.dataset.links['data'][i].tocoo().row
                    new_nid2 = self.dataset.links['data'][i].tocoo().col        
                
                etype = str(meta_path[0]) + '_' + str(meta_path[1])                
                
                if str(meta_path[0]) + '_' + str(meta_path[1]) == '1_0':
                    sim1[int(meta_path[1])] = torch.zeros([14328,4057])
                elif str(meta_path[0]) + '_' + str(meta_path[1]) == '1_3':
                    sim1[int(meta_path[1])] = torch.zeros([14328,20])
                elif str(meta_path[0]) + '_' + str(meta_path[1]) == '0_1':
                    sim1[int(meta_path[1])] = torch.zeros([4057,14328])
                elif str(meta_path[0]) + '_' + str(meta_path[1]) == '3_1':
                    sim1[int(meta_path[1])] = torch.zeros([20,14328])
                
                sim[int(meta_path[0])] = sim1

                target_fe = adapt_fes[new_nid1]
                neigh_fe = adapt_fes[new_nid2]
                sim_fe = torch.sum(target_fe.mul(neigh_fe), dim=1)  # dim=len(nid1)*1,对应位置元素点乘后，每一行求和。相当于对应行的向量点积
                sim_fe = sim_fe.reshape(len(sim_fe),-1)

                for ni in range(len(nid1)):
                    if nid1[ni] != nid2[ni]:
                        sim[int(meta_path[0])][int(meta_path[1])][nid1[ni]][nid2[ni]] = sim_fe[ni]

        sim2 = sim.copy()

        row = tuple(unlabel_idx.cpu().detach().numpy().tolist())
        target_fe = adapt_fes.clone().detach()  # adapt_fes: torch.Size([9040, 64])
        sim_tensor = sim2[0][1]
        for kk in range(k):
            max_id = torch.argmax(sim_tensor[unlabel_idx],1)
            if kk==0:
                neigh_fes = adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1]).clone().detach()
            else:
                neigh_fes = neigh_fes + adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1])
            
            sim_tensor[row,max_id] = 0
        neigh_fes = torch.tensor(neigh_fes/2.0, dtype=torch.float)
        adapt_fes[unlabel_idx] = neigh_fes
        
        res = []
        tmp = adapt_fes.cpu().detach().numpy().tolist()
        res.append(torch.tensor(tmp[:4057]))
        res.append(torch.tensor(tmp[4057:18385]))
        # res.append(torch.tensor(tmp[18385:]))
        return res

    def node_aug_heterograph_jd(self, node_features, unlabel_idx, k):
        sim,sim1 = {},{}
        distance0,distance1 = {},{}    

        adapt_fes = torch.cat((node_features[0],node_features[1]),axis=0)
            
        for i, meta_path in self.dataset.links['meta'].items():
            nid1 = self.dataset.links['data'][i].tocoo().row - self.dataset.nodes['shift'][meta_path[0]]
            nid2 = self.dataset.links['data'][i].tocoo().col - self.dataset.nodes['shift'][meta_path[1]]
            new_nid1 = self.dataset.links['data'][i].tocoo().row
            new_nid2 = self.dataset.links['data'][i].tocoo().col
            etype = str(meta_path[0]) + '_' + str(meta_path[1])
            distance0[int(meta_path[0])] = self.dataset.nodes['shift'][meta_path[0]]
            distance1[int(meta_path[1])] = self.dataset.nodes['shift'][meta_path[1]]

            if str(meta_path[0]) + '_' + str(meta_path[1]) == '0_1':
                sim1[int(meta_path[1])] = torch.zeros([3587,5916])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '1_0':
                sim1[int(meta_path[1])] = torch.zeros([5916,3587])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '1_1':
                sim1[int(meta_path[1])] = torch.zeros([5916,5916])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '0_0':
                sim1[int(meta_path[1])] = torch.zeros([3587,3587])

            sim[int(meta_path[0])] = sim1

            target_fe = adapt_fes[new_nid1]
            neigh_fe = adapt_fes[new_nid2]
            
            sim_fe = torch.sum(target_fe.mul(neigh_fe), dim=1)  # dim=len(nid1)*1,对应位置元素点乘后，每一行求和。相当于对应行的向量点积
            sim_fe = sim_fe.reshape(len(sim_fe),-1)

            for ni in range(len(nid1)):
                if nid1[ni] != nid2[ni]:
                    sim[int(meta_path[0])][int(meta_path[1])][nid1[ni]][nid2[ni]] = sim_fe[ni]

        sim2 = sim.copy()
        
        row = tuple(unlabel_idx.cpu().detach().numpy().tolist())
        target_fe = adapt_fes.clone().detach()  # adapt_fes: torch.Size([9040, 64])
        sim_tensor = torch.cat((sim2[0][0],sim2[0][1]),axis=1)
        for kk in range(k):
            max_id = torch.argmax(sim_tensor[unlabel_idx],1)
            if kk==0:
                neigh_fes = adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1]).clone().detach()
            else:
                neigh_fes = neigh_fes + adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1])
            
            sim_tensor[row,max_id] = 0
        
        neigh_fes = torch.tensor(neigh_fes/2.0, dtype=torch.float)
        adapt_fes[unlabel_idx] = neigh_fes
        
        res = []
        tmp = adapt_fes.cpu().detach().numpy().tolist()
        res.append(torch.tensor(tmp[:3587]))
        res.append(torch.tensor(tmp[3587:]))
        return res

    def node_aug_heterograph_ogbm(self, node_features, unlabel_idx, k):
        sim,sim1 = {},{}
        distance0,distance1 = {},{}
        print('node_features>>>>>> ',self.dataset.links['meta'].items())
    
        adapt_fes = torch.cat((node_features[0],node_features[1]),axis=0)
            
        for i, meta_path in self.dataset.links['meta'].items():
            nid1 = self.dataset.links['data'][i].tocoo().row - self.dataset.nodes['shift'][meta_path[0]]
            nid2 = self.dataset.links['data'][i].tocoo().col - self.dataset.nodes['shift'][meta_path[1]]
            new_nid1 = self.dataset.links['data'][i].tocoo().row
            new_nid2 = self.dataset.links['data'][i].tocoo().col
            etype = str(meta_path[0]) + '_' + str(meta_path[1])
            distance0[int(meta_path[0])] = self.dataset.nodes['shift'][meta_path[0]]
            distance1[int(meta_path[1])] = self.dataset.nodes['shift'][meta_path[1]]
            
            if str(meta_path[0]) + '_' + str(meta_path[1]) == '1_0':
                sim1[int(meta_path[1])] = torch.zeros([5394,2375])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '0_0':
                sim1[int(meta_path[1])] = torch.zeros([2375,2375])
            elif str(meta_path[0]) + '_' + str(meta_path[1]) == '0_1':
                sim1[int(meta_path[1])] = torch.zeros([2375,5394])

            sim[int(meta_path[0])] = sim1

            target_fe = adapt_fes[new_nid1]
            neigh_fe = adapt_fes[new_nid2]
            sim_fe = torch.sum(target_fe.mul(neigh_fe), dim=1)  # dim=len(nid1)*1,对应位置元素点乘后，每一行求和。相当于对应行的向量点积
            sim_fe = sim_fe.reshape(len(sim_fe),-1)

            for ni in range(len(nid1)):
                if nid1[ni] != nid2[ni]:
                    sim[int(meta_path[0])][int(meta_path[1])][nid1[ni]][nid2[ni]] = sim_fe[ni]

        sim2 = sim.copy()

        row = tuple(unlabel_idx.cpu().detach().numpy().tolist())
        target_fe = adapt_fes.clone().detach()  # adapt_fes: torch.Size([9040, 64])
        sim_tensor = torch.cat((sim2[0][0],sim2[0][1]),axis=1)
        for kk in range(k):
            max_id = torch.argmax(sim_tensor[unlabel_idx],1)
            if kk==0:
                neigh_fes = adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1]).clone().detach()
            else:
                neigh_fes = neigh_fes + adapt_fes[max_id].reshape(len(max_id),adapt_fes.size()[1])
            
            sim_tensor[row,max_id] = 0
        neigh_fes = torch.tensor(neigh_fes/2.0, dtype=torch.float)
        adapt_fes[unlabel_idx] = neigh_fes
        
        res = []
        # [(0, 3060), (1, 7965), (2, 6934), (3, 3990)]
        tmp = adapt_fes.cpu().detach().numpy().tolist()
        res.append(torch.tensor(tmp[:2375]))
        res.append(torch.tensor(tmp[2375:]))
        return res