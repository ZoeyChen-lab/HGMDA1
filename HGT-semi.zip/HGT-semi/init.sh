pip install aii-pypai -i https://pypi.antfin-inc.com/simple/ -U
pip uninstall couler -y
pip install couler-core ant-couler -i https://pypi.antfin-inc.com/simple/ -U

# pip install dgl-cu110 -i https://pypi.antfin-inc.com/simple/

echo "export DGLBACKEND"
export DGLBACKEND="pytorch"
echo "pip list"
pip list
echo "ls /dev"
ls /dev