import dgl
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl.function as fn
from dgl.nn.functional import edge_softmax

class HGTLayer(nn.Module):
    def __init__(self, in_dim, out_dim, num_types, num_relations, n_heads, unlabel_idx1, dropout = 0.2, use_norm = False, is_change_fe = False):
        super(HGTLayer, self).__init__()

        self.in_dim        = in_dim
        self.out_dim       = out_dim
        self.num_types     = num_types
        self.num_relations = num_relations
        self.n_heads       = n_heads
        self.d_k           = out_dim // n_heads
        self.sqrt_dk       = math.sqrt(self.d_k)
        
        self.k_linears   = nn.ModuleList()
        self.q_linears   = nn.ModuleList()
        self.v_linears   = nn.ModuleList()
        self.a_linears   = nn.ModuleList()
        self.norms       = nn.ModuleList()
        self.use_norm    = use_norm
        
        self.is_change_fe = is_change_fe
        self.unlabel_idx = unlabel_idx1
        
        for t in range(num_types):
            self.k_linears.append(nn.Linear(in_dim,   out_dim))
            self.q_linears.append(nn.Linear(in_dim,   out_dim))
            self.v_linears.append(nn.Linear(in_dim,   out_dim))
            self.a_linears.append(nn.Linear(out_dim,  out_dim))
            if use_norm:
                self.norms.append(nn.LayerNorm(out_dim))
            
        self.relation_pri   = nn.Parameter(torch.ones(num_relations, self.n_heads))
        self.relation_att   = nn.Parameter(torch.Tensor(num_relations, n_heads, self.d_k, self.d_k))
        self.relation_msg   = nn.Parameter(torch.Tensor(num_relations, n_heads, self.d_k, self.d_k))
        self.skip           = nn.Parameter(torch.ones(num_types))
        self.drop           = nn.Dropout(dropout)
        
        nn.init.xavier_uniform_(self.relation_att)
        nn.init.xavier_uniform_(self.relation_msg)

    def edge_attention(self, edges):
        etype = edges.data['id'][0]
        relation_att = self.relation_att[etype]
        relation_pri = self.relation_pri[etype]
        relation_msg = self.relation_msg[etype]
        key   = torch.bmm(edges.src['k'].transpose(1,0), relation_att).transpose(1,0)
        att   = (edges.dst['q'] * key).sum(dim=-1) * relation_pri / self.sqrt_dk
        # -------------------------------------------------------------------
        # att   = att.mul(torch.sigmoid(edges.data['w'].float()).reshape(edges.data['w'].shape[0],1))
        # att   = att.float()
        # print('edge weight>>>>>>',edges.data['w'].shape)
        # print('att weight>>>>>>',att.mul(edges.data['w'].reshape(edges.data['w'].shape[0],1)).shape)
        val   = torch.bmm(edges.src['v'].transpose(1,0), relation_msg).transpose(1,0)
        return {'a': att, 'v': val}
    
    def message_func(self, edges):
        return {'v': edges.data['v'], 'a': edges.data['a']}
    
    def reduce_func(self, nodes):
        att = F.softmax(nodes.mailbox['a'], dim=1)
        h   = torch.sum(att.unsqueeze(dim = -1) * nodes.mailbox['v'], dim=1)
        return {'t': h.view(-1, self.out_dim)}
    
    def forward(self, G, inp_key, out_key, num_cf):
        node_dict, edge_dict = G.node_dict, G.edge_dict
        for srctype, etype, dsttype in G.canonical_etypes:
            k_linear = self.k_linears[node_dict[srctype]]
            v_linear = self.v_linears[node_dict[srctype]] 
            q_linear = self.q_linears[node_dict[dsttype]]
            
            G.nodes[srctype].data['k'] = k_linear(G.nodes[srctype].data[inp_key]).view(-1, self.n_heads, self.d_k)
            G.nodes[srctype].data['v'] = v_linear(G.nodes[srctype].data[inp_key]).view(-1, self.n_heads, self.d_k)
            G.nodes[dsttype].data['q'] = q_linear(G.nodes[dsttype].data[inp_key]).view(-1, self.n_heads, self.d_k)
            
            G.apply_edges(func=self.edge_attention, etype=etype)
        G.multi_update_all({etype : (self.message_func, self.reduce_func) \
                            for etype in edge_dict}, cross_reducer = 'mean')
        
        new_h = {}
        for ntype in G.ntypes:
            n_id = node_dict[ntype]
            alpha = torch.sigmoid(self.skip[n_id])
            
            ## kk
            tt = G.dstnodes[ntype].data['t'].view(-1, self.out_dim)
            dst_nodes = G.nodes[ntype].data[inp_key]
            
            ######  is_change_fe ######
            if num_cf != 0:
                is_label = G.dstnodes[ntype].data['is_label'].view(-1,1)
                label_nodes = is_label*dst_nodes
                unlabel_nodes = (1-is_label)*dst_nodes
                unlabel_t = (1-is_label)*tt

                unlabel_idx = (is_label == 0).nonzero()[:,0]

                delta = torch.abs(unlabel_t[unlabel_idx] - unlabel_nodes[unlabel_idx])
                sorted_values,sorted_indexs = torch.sort(delta, dim=-1) #按行排序，sorted_values[:,0]得到邻居节点最相似的特征

                dst_fe = torch.gather(unlabel_nodes[unlabel_idx],1,sorted_indexs[:,0:num_cf].view(-1,num_cf)) #按行取对应位置的特征：目标节点对应的特征
                t_fe = torch.gather(unlabel_t[unlabel_idx],1,sorted_indexs[:,0:num_cf].view(-1,num_cf)) #按行取对应位置的特征：目标节点对应的特征

                # 替换目标节点的特征
                # dim=1表示逐行进行列填充
                unlabel_nodes[unlabel_idx] = unlabel_nodes[unlabel_idx].scatter(1, sorted_indexs[:,0:num_cf].view(-1,num_cf), t_fe.view(-1,num_cf))

                # 替换邻居节点的特征
                unlabel_t[unlabel_idx] = unlabel_t[unlabel_idx].scatter(1, sorted_indexs[:,0:num_cf].view(-1,num_cf), dst_fe.view(-1,num_cf))
                dst_nodes = label_nodes + unlabel_nodes
                tt = is_label*tt + unlabel_t

                ### 检查节点是否完成特征交换
    #                 for iii in range(len(dst_nodes)):
    #                     print('***************************',iii)
    #                     for iij in range(len(dst_nodes[iii])):
    #                         if dst_nodes[iii][iij] != dd[iii][iij]:
    #                             print('dst_nodes is diff!!!! ',dst_nodes[iii][iij] ,dd[iii][iij] )
    #                         if t[iii][iij]  != tt[iii][iij] :
    #                             print('t is diff!!!! ',t[iii][iij] ,tt[iii][iij] )
                trans_out = self.a_linears[n_id](tt)
                trans_out = trans_out * alpha + dst_nodes * (1-alpha)
            ## kk
            else:
                trans_out = self.a_linears[n_id](G.dstnodes[ntype].data['t'].view(-1, self.out_dim))
                trans_out = trans_out * alpha + G.nodes[ntype].data[inp_key] * (1-alpha)
                
            if self.use_norm:
                G.nodes[ntype].data[out_key] = self.drop(self.norms[n_id](trans_out))
            else:
                G.nodes[ntype].data[out_key] = self.drop(trans_out)
                
    def __repr__(self):
        return '{}(in_dim={}, out_dim={}, num_types={}, num_types={})'.format(
            self.__class__.__name__, self.in_dim, self.out_dim,
            self.num_types, self.num_relations)
                
class HGT(nn.Module):
    def __init__(self, G, n_inps, n_hid, n_out, n_layers, n_heads, unlabel_idx, use_norm = True):
        super(HGT, self).__init__()
        
        ##kk
        self.gcs = nn.ModuleList()
        self.gcs2 = nn.ModuleList()
        ##kk
        
        self.n_inps = n_inps
        self.n_hid = n_hid
        self.n_out = n_out
        self.n_layers = n_layers
        self.adapt_ws  = nn.ModuleList()
        for t in range(len(G.node_dict)):
            self.adapt_ws.append(nn.Linear(n_inps[t], n_hid))
        for _ in range(n_layers):
            self.gcs.append(HGTLayer(n_hid, n_hid, len(G.node_dict), len(G.edge_dict), n_heads, unlabel_idx, use_norm = use_norm))

        self.out = nn.Linear(n_hid, n_out)
        self.norm = nn.LayerNorm(n_out)

    def forward(self, G, out_key, num_cf):
        for ntype in G.ntypes:
            n_id = G.node_dict[ntype]
            G.nodes[ntype].data['h'] = torch.tanh(self.adapt_ws[n_id](G.nodes[ntype].data['inp'])) #F.gelu    #torch.tanh
        for i in range(self.n_layers):
            self.gcs[i](G, 'h', 'h', num_cf)
        return self.out(G.nodes[out_key].data['h']), G.nodes[out_key].data['h']
    def __repr__(self):
        return '{}(n_inp={}, n_hid={}, n_out={}, n_layers={})'.format(
            self.__class__.__name__, self.n_inp, self.n_hid,
            self.n_out, self.n_layers)
