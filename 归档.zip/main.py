# -*- coding: utf-8 -*-
from pypai.job import PythonJobBuilder
from pypai.conf import ExecConf, KMConf


def main():
    # 资源设置: cpu gpu mem disk 大小. 单位分别为 个 个 Mb Mb 代表job最大占用资源
    # 如果提交到alipay_stl集群, ExecConf这里要设置 gpu_type='v100'
    master = ExecConf(num=10, memory=51200, gpu_num=1, disk_m=10240)
    
    # 镜像列表：https://aistudio.alipay.com/project/assets/docker-image
    # 推荐官方镜像142
    
    km_conf = KMConf(image="image_path")
    # 更多job参数见 https://aistudio.alipay.com/doc/python_job.html
    
    job = PythonJobBuilder(source_root='./',
                           command='source init.sh && python run_all.py',
                           main_file='run_all.py',
                           master=master,
                           km_conf=km_conf,
                           runtime='pytorch')
    
    # 如需指定任务最长运行时间(提交任务后无需管理, 到点自动kill, 释放卡资源)
    labels = dict()
    labels['limited_time'] = 60 # 单位为分钟, 表示限时60分钟
    job.labels = labels

    job.run()


if __name__ == '__main__':
    main()
