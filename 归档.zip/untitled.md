pip install dgl-cu110 -i https://pypi.antfin-inc.com/simple/
pip install torch==1.9.0 torchvision==0.10.0 -i https://pypi.antfin-inc.com/simple/
pip install aii_pypai -i https://pypi.antfin-inc.com/simple/
pip install aistudio_common -i https://pypi.antfin-inc.com/simple/
pip install tensorflow==1.14.0 -i https://pypi.antfin-inc.com/simple/



<!-- pip install dgl -f https://data.dgl.ai/wheels/repo.html -i https://pypi.antfin-inc.com/simple/
pip install tensorflow -i https://pypi.antfin-inc.com/simple/ -->

下载文件 wget -c http://...
解压缩文件 tar -zxvf py_model.tar.gz
重命名文件 mv tf_model node_data_old4.csv

安装稀疏邻接矩阵相乘的包
教程：https://blog.csdn.net/qq_36618444/article/details/108099479

pip install torch-scatter -f https://data.pyg.org/whl/torch-1.9.0+${CUDA}.html

pip install nltk -i https://pypi.antfin-inc.com/simple/


提交git:
git status // 查看修改过的文件
git add <file-path> // 将修改过的文件手动加入索引，供下一步提交
git commit -m "这里填写提交记录" // 提交变动文件，同时增加注释

将特性分支推送到中央仓库。
在 codecenter 仓库中执行以下命令：
git push -u origin feature

在以上命令中，git push feature 即可将分支推送到中央仓库（origin），-u选项用于设置本地分支去跟踪远程对应的分支，您可以使用 git push命令去指定推送分支的参数。


pip install aii-pypai --index-url='https://pypi.antfin-inc.com/simple' -I